function raizQuadrada(a) {
    return Math.pow(a , 2);
}
module.exports = raizQuadrada;