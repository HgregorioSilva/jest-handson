function numeroTruncado(a) {
    return Math.trunc(a);
}

module.exports = numeroTruncado;