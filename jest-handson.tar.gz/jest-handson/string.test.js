test("Tratamento de espaço em senha", () => {
    var input = "senha"
    var output = "senha"

    
    expect(output).toEqual(input);
})