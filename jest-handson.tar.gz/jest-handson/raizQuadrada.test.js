const raizQuadrada = require('./raizQuadrada');

test('Test', () => {
    expect(raizQuadrada(7)).toBe(49);
});